/*
 * Created on 02-feb-2007 by azabala
 *
 */
package com.iver.cit.jdwglib.dwg.objects;

import com.iver.cit.jdwglib.dwg.DwgObject;

/**
 * @author alzabord
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DwgImage extends DwgObject {

	/**
	 * @param index
	 */
	public DwgImage(int index) {
		super(index);
		// TODO Auto-generated constructor stub
	}
	public Object clone(){
		DwgImage obj = new DwgImage(index);
		this.fill(obj);
		return obj;
	}
	
	protected void fill(DwgObject obj){
		super.fill(obj);
		//DwgImage myObj = (DwgImage)obj;

	}

}
